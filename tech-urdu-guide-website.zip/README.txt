TECH URDU GUIDE — SETUP
1) Replace your-email@example.com in contact.html.
2) Replace YOUR-DOMAIN.com in robots.txt and sitemap.xml.
3) Upload all files to your hosting root (public_html) or a static hosting service.
4) Connect your own domain and enable HTTPS.
5) Open the site and test every menu link on mobile.
6) In Google AdSense, enter the root domain (for example example.com), not /index.html.
7) Add the exact AdSense code Google gives you. Do not alter the ad code.
8) Keep adding genuinely original, useful articles before requesting review.

This package is a starter website, not a guarantee of AdSense approval. Google reviews the live site and its content/policies.
